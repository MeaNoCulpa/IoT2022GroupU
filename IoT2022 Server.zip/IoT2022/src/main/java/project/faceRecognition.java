package project;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Servlet implementation class faceRecognition
 */
@MultipartConfig
public class faceRecognition extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private int requestCounter = 0;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public faceRecognition() {
        super();
        // TODO Auto-generated constructor stub
    }


    
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/* doGet(request, response); 
		 * 
		 */
		
		Part image_part = request.getPart("file");
		
		String chemin = "C:\\Users\\yanns\\IoT\\IoT2022\\src\\main\\img\\picture.jpg";
				
		Path path = Path.of(chemin);
		try(InputStream is = image_part.getInputStream()){
		    Files.copy(is, path);
		}
		
		System.out.println("Received an Image!");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Use image file to contact the API
		
		Files.delete(Path.of("C:\\Users\\yanns\\IoT\\IoT2022\\src\\main\\img\\picture.jpg"));
		
		// TODO Append the request response depending on the API's response
		// JSON Format {status, name, access}
		
		
		
		switch (requestCounter % 3) {
			case 2:
				response.getWriter().append("{\"status\":\"success\", \"name\":\"John Smith\", \"access\":true}");
				break;
			case 0:
				response.getWriter().append("{\"status\":\"success\", \"name\":\"Mary Jane\", \"access\":false}");
				break;
			case 1:
				response.getWriter().append("{\"status\":\"success\", \"name\":\"\", \"access\":false}");
				break;
		}
		requestCounter+=1;
			
	}

}